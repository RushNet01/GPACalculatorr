/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sheymijava.gpacalculatorr;

class Course {
    String courseNameAndCode;
    int courseUnit;
    int courseScore;
    String grade;
    int gradeUnit;

    public Course(String courseNameAndCode, int courseUnit, int courseScore) {
        this.courseNameAndCode = courseNameAndCode;
        this.courseUnit = courseUnit;
        this.courseScore = courseScore;
        calculateGradeAndGradeUnit();
    }

    private void calculateGradeAndGradeUnit() {
        if (courseScore >= 70) {
            grade = "A";
            gradeUnit = 5;
        } else if (courseScore >= 60) {
            grade = "B";
            gradeUnit = 4;
        } else if (courseScore >= 50) {
            grade = "C";
            gradeUnit = 3;
        } else if (courseScore >= 45) {
            grade = "D";
            gradeUnit = 2;
        } else if (courseScore >= 40) {
            grade = "E";
            gradeUnit = 1;
        } else {
            grade = "F";
            gradeUnit = 0;
        }
    }
}
