/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sheymijava.gpacalculatorr;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import sheymijava.gpacalculatorr.Course;



public class GPACalculatorr {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Course> courses = new ArrayList<>();

        System.out.println("Welcome to the GPA Calculator");

        while (true) {
            // Get user input for course details
            System.out.print("Enter Course Name and Code (or press Enter to finish): ");
            String courseNameAndCode = scanner.nextLine();

            if (courseNameAndCode.trim().isEmpty())
                break;

            System.out.print("Enter Course Unit: ");
            int courseUnit = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter Course Score: ");
            int courseScore = Integer.parseInt(scanner.nextLine());

            // Create a Course object and add it to the list
            Course course = new Course(courseNameAndCode, courseUnit, courseScore);
            courses.add(course);
        }

        
        System.out.println("|----------------------------|-----------------------|------------|---------------------|");
        System.out.println("| COURSE & CODE              | COURSE UNIT           | GRADE      | GRADE-UNIT          |");
        System.out.println("|----------------------------|-----------------------|------------|---------------------|");

        for (Course course : courses) {
            System.out.printf("| %-27s | %-21d | %-10s | %-20d |\n",
                    course.courseNameAndCode, course.courseUnit, course.grade, course.gradeUnit);
        }

        double totalQualityPoint = courses.stream().mapToDouble(course -> course.courseUnit * course.gradeUnit).sum();
        int totalGradeUnit = courses.stream().mapToInt(course -> course.courseUnit).sum();
        double gpa = totalQualityPoint / totalGradeUnit;

        System.out.println("|---------------------------------------------------------------------------------------|");
        System.out.printf("Your GPA is = %.2f to 2 decimal places.\n", gpa);

        scanner.close();
    }
}
